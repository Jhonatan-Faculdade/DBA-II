import mysql.connector as mysql

conexao = mysql.connect(
    host='localhost',
    user="root",
    password="Jfr@13281328",
    database="pgi_teste01", 
    port=3306, 
)